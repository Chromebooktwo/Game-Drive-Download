Game Drive Text Page - 
This is the Game Drive Text Page, this page has info about the Game Drive USB, which contains many fun offline games and some nice tools!

Download the games and tools to your laptop/pc from this USB, then start using the games and tools from your device!

Have fun!!!


- Note:  Please do not play games and use tools directly from the USB, instead download the games and tools to your pc/laptop/any other device that has a monitor, keyboard and mouse, like a Chromebook, then start using the games and tools!

Some games and tools came from G - Home, others came from One HTML Page Challenge, and some from Tech Geek United/Offline HTML Games and Straker GitHub Pages and some from me, (Chromebooktwo)!

One HTML Page Challenge website.
Link: 
https://onehtmlpagechallenge.com/ 

Tech Geek United/Offline HTML Games GitHub website.
Link: 
https://github.com/TechGeekUnited/Offline-HTML-Games/tree/main 

Straker GitHub website.
Link: 
https://gist.github.com/straker 

G - Home website, G - Home is a website that is a list to find games and cool tools online! 
Link: 
https://milannikulin.website3.me/ 

Some games are posted on my Github too! Here the link for my Github page!
My Github Page (I am the creator of G - Home!). 
Link: 
https://github.com/Chromebooktwo 


WARNING SOME GAMES AND TOOLS MAY CONTAIN FLASHING LIGHTS!





#############################################################################

Tech Geek United/Offline HTML Games README



# Offline-HTML-Games
Offliine(Local) HTML Tools/games most in only one html file that can be opened directly through the browser with no Webserver needed WHAT SO EVER!

# Credits (WIP!)
As you have most likely figured out almost none of these tools/games are made by me; I only compacted them to one file minimized them and uploaded them here, below is the list of github projects i used to make this respitory if your project is included but not mentioned or you would like it removed please feel free to create a new issue!

Projects used

[oldj/html5 tower defense](https://github.com/oldj/html5-tower-defense)

[Dystopia user181/connect pipes polygonal](https://github.com/Dystopia-user181/connect-pipes-polygonal)

[Metroxe/one html page challenge](https://github.com/Metroxe/one-html-page-challenge)

[orteil/musicgen](https://orteil.dashnet.org/musicgen)
